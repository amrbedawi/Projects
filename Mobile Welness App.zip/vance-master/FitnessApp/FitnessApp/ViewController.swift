//
//  ViewController.swift
//  FitnessApp
//
//  Created by codeplus on 3/28/20.
//  Copyright © 2020 Duke University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

